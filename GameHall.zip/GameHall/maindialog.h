﻿#ifndef MAINDIALOG_H
#define MAINDIALOG_H

#include "packdef.h"

namespace Ui {
class MainDialog;
}

class MainDialog : public QDialog
{
    Q_OBJECT

public:
    explicit MainDialog(QWidget *parent = 0);
    ~MainDialog();
    void registerEvent(string userName);

    void closeEvent(QCloseEvent *e);
signals:
    void SIG_close();
    void SIG_joinZone(int);
private slots:
    void on_pb_FiveInLine_clicked();

    
    void on_pb_FileUpload_clicked();
    
    void on_pb_FileUpLoad_clicked();

    void on_pb_FileDownLoad_clicked();

private:
    Ui::MainDialog *ui;
};

#endif // MAINDIALOG_H
