﻿#include "audio_write.h"

audio_write::audio_write(QObject *parent)
{
    //初始化设备
    //声卡采样格式
    format.setSampleRate(8000);
    format.setChannelCount(1);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::UnSignedInt);
    QAudioDeviceInfo info = QAudioDeviceInfo::defaultInputDevice();
    if (!info.isFormatSupported(format)) {
        QMessageBox::information(NULL , "提示", "打开音频设备失败");
        format = info.nearestFormat(format);
    }
    m_recordState = audio_state::Stop;
    audio_out = new QAudioOutput(format, this);
    myBuffer_out = audio_out->start();

}

audio_write::~audio_write()
{
    delete audio_out;
}
//通过该函数 就可以完成声音播放
void audio_write::slot_net_rx(QByteArray ba)
{
    myBuffer_out->write( ba.data() , 640 );
}
