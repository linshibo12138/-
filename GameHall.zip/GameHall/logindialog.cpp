﻿#include "logindialog.h"
#include "ui_logindialog.h"

LoginDialog::LoginDialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginDialog)
{
    qDebug() << __func__;
    ui->setupUi(this);
    setUI();
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

void LoginDialog::closeEvent(QCloseEvent *e)
{
    qDebug() << __func__;
    if(QMessageBox::question(this, "退出", "是否退出") == QMessageBox::Yes) {
        //发信号
        Q_EMIT SIG_close();
        //同意关闭事件
        e->accept();
    }
    else {
        //忽略关闭事件
        e->ignore();
    }
}

void LoginDialog::setUI()
{
    qDebug() << __func__;
    this->setWindowTitle("登录&注册");
    //加载图片
    QPixmap pixmap(":/new/prefix1/resource/images/background.jpg");
    //画板，添加背景
    QPalette pal;
    pal.setBrush(backgroundRole(), QBrush(pixmap));
    this->setPalette(pal);
    setAutoFillBackground(true);

    //默认登录页面
    ui->tw_page->setCurrentIndex(1);
    qDebug() << __func__;
}

//登录清空
void LoginDialog::on_pb_LoginClear_clicked()
{
    ui->le_LoginPassword->setText("");
    ui->le_LoginTel->setText("");
}

//登录提交
void LoginDialog::on_pb_LoginCommit_clicked()
{
    //1.读取数据
    QString Tel = ui->le_LoginTel->text();
    QString Passwd = ui->le_LoginPassword->text();
    QString TelTemp = Tel;
    QString PasswdTemp = Passwd;

    //2.进行检验

    //2.1三个账户信息不能为空不能全部为空格
    if(Tel.isEmpty() || Passwd.isEmpty()
     ||(TelTemp.remove(' ')).isEmpty() || (PasswdTemp.remove(' ')).isEmpty()
     || Tel.size() != 11 || Passwd.size() > 20) {
        QMessageBox::about(this, "提示", "输入不合法");
        return;
    }

    //2.2正则表达式检测手机号
    QRegExp exp("^1[3-8][0-9]\{9\}$");
    if(!exp.exactMatch(Tel)) {
        QMessageBox::about(this, "提示", "手机号输入不合法");
        return;
    }

    //3.密码SHA-256加密、加盐（加盐防止彩虹表破解密码）先加盐后加密
    Passwd = _DEF_SHA256_SALT + Passwd;
    QByteArray data = Passwd.toUtf8();
    QByteArray hash = QCryptographicHash::hash(data, QCryptographicHash::Sha256);
    Passwd = QString(hash.toHex());

    //4.发送数据
    Q_EMIT SIG_LoginCommit(Tel, Passwd);
}

//注册清空
void LoginDialog::on_pb_RegisterClear_clicked()
{
    ui->le_RegisterName->setText("");
    ui->le_RegisterPassword->setText("");
    ui->le_RegisterTel->setText("");
    ui->le_RegsterConfirm->setText("");
}

//注册提交
void LoginDialog::on_pb_RegisterCommit_clicked()
{
    //1.读取数据
    QString Tel = ui->le_RegisterTel->text();
    QString Passwd = ui->le_RegisterPassword->text();
    QString Name = ui->le_RegisterName->text();
    QString Confirm = ui->le_RegsterConfirm->text();
    QString TelTemp = Tel;
    QString NameTemp = Name;
    QString PasswdTemp = Passwd;

    //2.进行检验
    //2.0 检验两次输入密码是否相同
    if(Passwd != Confirm) {
        QMessageBox::about(this, "register fail", "两次输入密码不一致");
        return;
    }
    //2.1三个账户信息不能为空不能全部为空格
    if(Name.isEmpty() || Tel.isEmpty() || Passwd.isEmpty() || Confirm.isEmpty()
     || (NameTemp.remove(' ')).isEmpty() || (TelTemp.remove(' ')).isEmpty()
     || (PasswdTemp.remove(' ')).isEmpty()
     || Name.size() > 20 || Tel.size() != 11 || Passwd.size() > 20) {
        QMessageBox::about(this, "提示", "输入不合法");
        return;
    }

    //2.2正则表达式检测手机号
    QRegExp exp("^1[3-8][0-9]\{9\}$");
    if(!exp.exactMatch(Tel)) {
        QMessageBox::about(this, "提示", "手机号输入不合法");
        return;
    }

    //3.密码SHA-256加密、加盐（加盐防止彩虹表破解密码）先加盐后加密
    Passwd = _DEF_SHA256_SALT + Passwd;
    QByteArray data = Passwd.toUtf8();
    QByteArray hash = QCryptographicHash::hash(data, QCryptographicHash::Sha256);
    Passwd = QString(hash.toHex());


    //4.发送数据
    Q_EMIT SIG_RegisterCommit(Tel, Name, Passwd);


}
