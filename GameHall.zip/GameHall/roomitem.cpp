﻿#include "roomitem.h"
#include "ui_roomitem.h"


RoomItem::RoomItem(int roomID, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RoomItem)
{
    ui->setupUi(this);
    info = new ROOM_INFO;
    RoomID = roomID;
}

RoomItem::~RoomItem()
{
    delete info;
    info = nullptr;
    delete ui;
}

void RoomItem::setInfo()
{
    QString txt = QString("五子棋-0%1房").arg(RoomID);
    ui->label->setText(txt);
}


void RoomItem::on_pb_GoToWatch_clicked()
{
    qDebug() <<"RoomItem::on_pb_GoToWatch_clicked";
    if(!info->isPlaying) {
        QMessageBox::about(this, "提示", "游戏未开始， 暂时不能观战");
        return;
    }
    if(info->TotalCountInRoom >= _DEF_ROOM_WATCHER_COUNT + 2) {
        QMessageBox::about(this, "提示", "房间人数已达上限， 暂时不能观战");
        return;
    }
    Q_EMIT SIG_JoinRoomInFreedom(RoomID, Watcher);
}

void RoomItem::on_pb_GoToPlay_clicked()
{
    qDebug() << "RoomItem::on_pb_GoToPlay_clicked";
    if(info->TotalCountInRoom  == 0) {
        Q_EMIT SIG_JoinRoomInFreedom(RoomID, Host);
    }
    else if(info->TotalCountInRoom == 1) {
        Q_EMIT SIG_JoinRoomInFreedom(RoomID, Player);
    }
    else {
        QMessageBox::about(this, "提示", "正在对弈中， 暂时不能参战，可前往观战区");
        return;
    }
}
