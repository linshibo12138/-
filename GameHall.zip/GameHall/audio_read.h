﻿#ifndef AUDIO_READ_H
#define AUDIO_READ_H

#include "audio_common.h"
#include <QObject>

class audio_read : public QObject {
    Q_OBJECT
public:
    explicit audio_read(QObject* parent = nullptr);
    ~audio_read();
    //为了更好的管理状态, 需要添加状态位, 避免出现 (开始->开始 暂停->暂停 状态的切换)
    //初始化状态为结束 , 开始状态为 recording , 暂停状态为 pausing , 先判断再执行开始和暂停
    enum audio_state{Stop, Record, Pause};
signals:
    //定时采集的数据，以信号形式发送
    void SIG_audioFrame(QByteArray ba);
public slots:
    //开始采集
    void start();
    //暂停采集
    void pause();
    //定时超时槽函数
    void slot_readMore();
private:
    QAudioFormat  format;
    QTimer*       m_timer;
    QIODevice*    myBuffer_in;
    QAudioInput*  audio_in;
    int           m_recordState;
};

#endif // AUDIO_READ_H
