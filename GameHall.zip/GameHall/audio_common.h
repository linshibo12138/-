﻿#ifndef AUDIO_COMMON_H
#define AUDIO_COMMON_H

#include <QAudioInput>
#include <QAudioOutput>
#include <QAudioFormat>
#include <QAudioDeviceInfo>
#include <QMessageBox>
#include <QDebug>


#endif // AUDIO_COMMON_H
