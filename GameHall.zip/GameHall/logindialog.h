﻿#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H


#include "packdef.h"
#include "TcpClientMediator.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QWidget
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = 0);
    ~LoginDialog();
    void closeEvent(QCloseEvent *e);
    void setUI();

signals:
    void SIG_LoginCommit(QString tel, QString password);
    void SIG_RegisterCommit(QString tel, QString name, QString password);
    void SIG_close();

private slots:


    void on_pb_LoginClear_clicked();

    void on_pb_LoginCommit_clicked();

    void on_pb_RegisterClear_clicked();

    void on_pb_RegisterCommit_clicked();

private:
    Ui::LoginDialog *ui;
    INetMediator* m_clientMediator;
};

#endif // LOGINDIALOG_H
