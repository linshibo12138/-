﻿#include "fiveinlinezone.h"
#include "ui_fiveinlinezone.h"

FiveInLineZone::FiveInLineZone(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::FiveInLineZone)
{
    ui->setupUi(this);
    this->setWindowTitle("五子棋专区");
    m_layout = new QGridLayout;
    m_layout->setContentsMargins(0, 0, 0, 0);
    ui->wdg_roomGrid->setLayout(m_layout);
    for(int i = 1; i <= 120; ++i) {
        RoomItem* item = new RoomItem(i, 0);
        m_layout->addWidget(item, (i - 1) / 2, (i - 1) % 2);
        item->setInfo();
        connect(item, SIGNAL(SIG_JoinRoomInFreedom(int, int)),
                this, SLOT(slot_JoinRoomInFreedom(int, int)));
        connect(item, SIGNAL(SIG_Close()),
                this, SLOT(slot_QuitToMaindialog()));
    }


}

FiveInLineZone::~FiveInLineZone()
{
    //TODO:释放120个房间的空间

    //delete m_layout;
    //m_layout = NULL;
    delete ui;
}

void FiveInLineZone::DestroyRoom() {
    //m_layout->removeItem();
}


void FiveInLineZone::GetUserInfo(int userID, QString userName, int winCount, int failCount)
{
    this->userID = userID;
    ui->pb_icon->setIcon(QIcon(QPixmap(_DEF_DEFAULT_ICON)));
    ui->pb_icon->setIconSize(QSize(_DEF_FIVEINLINE_ICON_WIDTH, _DEF_FIVEINLINE_ICON_HEIGHT));
    ui->le_Name->setText(userName);
    ui->le_WinNum->setText(QString::number(winCount));
    ui->le_FailNum->setText(QString::number(failCount));

}

void FiveInLineZone::closeEvent(QCloseEvent *e)
{
    qDebug() << "FiveInLineZone::closeEvent";
    if(QMessageBox::question(this, "退出", "是否退出") == QMessageBox::Yes) {
        //发信号
        Q_EMIT SIG_close();
        //同意关闭事件
        e->accept();
    }
    else {
        //忽略关闭事件
        e->ignore();
    }
}

void slot_QuitToMaindialog() {

}

void FiveInLineZone::on_pb_StartPlay_clicked()
{
    Q_EMIT SIG_QUICKPLAY(this->userID);
}

void FiveInLineZone::on_pb_SendMessage_clicked()
{

}

void FiveInLineZone::slot_JoinRoomInFreedom(int roomID, int status) {
    Q_EMIT SIG_JOINROOM_RQ(this->userID, roomID, status);
}

