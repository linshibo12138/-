﻿#include "ckernel.h"
#include "TcpClientMediator.h"
#define NetPackMap(a)  m_netPackFunMap[(a) -  _DEF_PROTOCOL_BASE]



void CKernel::setNetPackFunMap()
{
    NetPackMap(_DEF_PACK_LOGIN_RS )        =       &CKernel::slot_dealLoginRs;
    NetPackMap(_DEF_PACK_REGISTER_RS)      =       &CKernel::slot_dealRegisterRs;
    NetPackMap(DEF_JOIN_ROOM_RS )          =       &CKernel::slot_joinRoomRs;
    NetPackMap(DEF_PACK_OFFLINE_RQ )       =       &CKernel::slot_offLineRq;
}

void CKernel::SendData(char *buf, int nLen)
{
    qDebug() <<"CKernel::SendData";
    m_client->SendData(0, buf, nLen);

}

CKernel::CKernel(QObject *parent) : QObject(parent),
    m_netPackFunMap(_DEF_PROTOCOL_COUNT, 0), userID(0),
    roomID(0), zoneID(0), userName(""), winCount(0), failCount(0),
    m_isHost(false), m_isPlayer(false), m_isWatcher(false), watcherCount(0)
{
    qDebug() << "CKernel::CKernel";

    setNetPackFunMap();
    m_client = new TcpClientMediator;
    m_logindialog = new LoginDialog;
    m_mainDialog = new MainDialog;
    m_fiveInLineZone = new FiveInLineZone;
    m_roomDialog = new RoomDialog;


    connect(m_client, SIGNAL(SIG_ReadyData( unsigned int, char*, int )),
            this, SLOT(slot_ReadyData( unsigned int, char*, int )));
    connect(m_logindialog, SIGNAL(SIG_close()),
            this, SLOT(DestroyInstance()));
    connect(m_logindialog, SIGNAL(SIG_LoginCommit(QString, QString)),
            this, SLOT(slot_loginCommit(QString, QString)));
    connect(m_logindialog, SIGNAL(SIG_RegisterCommit(QString, QString, QString)),
            this, SLOT(slot_RegisterCommit(QString, QString, QString)));
    connect(m_mainDialog, SIGNAL(SIG_close()),
            this, SLOT(DestroyInstance()));
    connect(m_mainDialog, SIGNAL(SIG_joinZone(int)),
            this, SLOT(slot_joinZone(int)));
    connect(m_fiveInLineZone,SIGNAL(SIG_close()),
            this, SLOT(slot_quitToMainDialog()));
    connect(m_fiveInLineZone,SIGNAL(SIG_JOINROOM_RQ(int,int,int)),
            this, SLOT(slot_joinRoomRq(int,int,int)));
    connect(m_fiveInLineZone,SIGNAL(SIG_QUICKPLAY(int)),
            this, SLOT(slot_quickplay(int)));
    connect(m_roomDialog, SIGNAL(SIG_RoomClose()),
            this, SLOT(slot_quitToZone()));

    m_client->OpenNet(_DEF_SERVER_IP, _DEF_TCP_PORT);
    m_logindialog->show();

}

CKernel::~CKernel()
{
    qDebug() << "CKernel::~CKernel()";

}

void CKernel::DestroyInstance()
{
    qDebug() << "CKernel::DestroyInstance";
    LeaveLogin();
    if(m_client) {
        m_client->CloseNet();
        delete m_client;
        m_client = nullptr;
    }
    if(m_mainDialog) {
        delete m_mainDialog;
        m_mainDialog = nullptr;
    }
    if(m_fiveInLineZone) {
        delete m_fiveInLineZone;
        m_fiveInLineZone = nullptr;
    }
}

void CKernel::LeaveLogin() {
    qDebug() << "CKernel::LeaveLogin";
    STRU_OFFLINE_RQ rq;
    rq.userID = userID;
    SendData((char*)&rq, sizeof(rq));
}

void CKernel::InitToLogin() {
    qDebug() <<"CKernel::InitLogin";
    //ui切换
    if(roomID != 0) {
        m_roomDialog->hide();
        roomID = 0;
    }
    if(zoneID != 0) {
        m_fiveInLineZone->hide();
        zoneID = 0;
    }

    m_mainDialog->hide();
    m_logindialog->show();

    userID = 0;
    userName = "";

}


void CKernel::slot_quitToMainDialog()
{
    qDebug() << "CKernel::slot_quitToMainDialog";
    //成员属性修改
    this->zoneID = 0;
    //请求
    STRU_LEAVE_ROOM_RQ rq;
    rq.userId = userID;
    SendData((char*)&rq, sizeof(rq));
    //ui跳转
    m_fiveInLineZone->hide();
    m_mainDialog->show();

}

void CKernel::slot_ReadyData(unsigned int lSendIP, char *buf, int nlen)
{
    qDebug() <<"CKernel::slot_ReadyData";
    //协议映射表
    PackType type = *(int*)buf;//(*(int*) 按照整型取数据
    if(type >= _DEF_PROTOCOL_BASE && type < _DEF_PROTOCOL_BASE + _DEF_PROTOCOL_COUNT) {
        //协议映射处理
        PFUN pf = NetPackMap( type );
        //执行函数
        (this->*pf)(lSendIP, buf, nlen);
    }
    //buf要回收
    delete[] buf;
}

void CKernel::slot_dealLoginRs(unsigned int lSendIP, char *buf, int nLen)
{
    qDebug() << "CKernel::slot_dealLoginRs";
    STRU_LOGIN_RS* rs = (STRU_LOGIN_RS*)buf;
    //根据不同结果显示
    qDebug() <<rs->result <<' '<<rs->name<<' '<<rs->userid;
    switch(rs->result) {
    case user_not_exist:
        QMessageBox::about(m_logindialog, "提示", "用户不存在， 登录失败");
        break;
    case password_error:
        QMessageBox::about(m_logindialog, "提示", "密码错误， 登录失败");
        break;
    case login_success:
        //ui切换
        m_logindialog->hide();
        m_mainDialog->registerEvent(rs->name);
        m_mainDialog->show();
        //存储
        userID = rs->userid;
        userName = QString::fromStdString(rs->name);
        break;
    default:
        QMessageBox::about(m_logindialog, "提示", "登录异常， 登录失败");
    }

}

void CKernel::slot_dealRegisterRs(unsigned int lSendIP, char *buf, int nLen)
{
    qDebug() << "CKernel::slot_dealRegisterRs";
    STRU_REGISTER_RS* rs = (STRU_REGISTER_RS*)buf;
    //根据不同结果显示
    switch(rs->result) {
    case tel_is_exist:
        QMessageBox::about(m_logindialog, "提示", "电话号码已被注册，注册失败");
        break;
    case name_is_exist:
        QMessageBox::about(m_logindialog, "提示", "昵称已存在，注册失败");
        break;
    case register_success:
        QMessageBox::about(m_logindialog, "提示", "注册成功");
        break;

    default:
        QMessageBox::about(m_logindialog, "提示", "注册异常， 注册失败");
    }

}

void CKernel::slot_loginCommit(QString tel, QString passwd) {
    qDebug() << "CKernel::slot_loginCommit";
    //封包
    STRU_LOGIN_RQ rq;
    strcpy(rq.tel, tel.toStdString().c_str());
    strcpy(rq.password, passwd.toStdString().c_str());
    //发送
    SendData((char*)&rq, sizeof(rq));

}
void CKernel::slot_RegisterCommit(QString tel, QString name, QString passwd) {
    qDebug() << "CKernel::slot_RegisterCommit";
    //封包
    STRU_REGISTER_RQ rq;
    strcpy(rq.tel, tel.toStdString().c_str());
    strcpy(rq.password, passwd.toStdString().c_str());
    strcpy(rq.name, name.toStdString().c_str());
    //发送
    SendData((char*)&rq, sizeof(rq));
}


void CKernel::slot_JoinZoneRq(int zoneID) {
    qDebug() <<" CKernel::slot_joinZone";
    STRU_JOIN_ZONE rq;
    rq.userID = userID;
    rq.zoneID = zoneID;
    this->zoneID = zoneID;
    SendData((char*)&rq, sizeof(rq));
    switch(zoneID) {
    case ENUM_FiveInLine:
        slot_accessFiveInLine();
        break;
    default:
        break;
    }
}

void CKernel::slot_joinRoomRq(int roomID, int status)
{
    qDebug() <<"CKernel::slot_joinRoomRq";
    STRU_JOIN_ROOM_RQ rq;
    rq.userID = this->userID;
    rq.roomID = roomID;
    rq.status = status;
    SendData((char*)&rq, sizeof(rq));
}

void CKernel::slot_joinRoomRs(unsigned int lSendIP, char *buf, int nLen)
{
    qDebug() << "CKernel::slot_joinRoomRs";
    STRU_JOIN_ROOM_RS* rs = (STRU_JOIN_ROOM_RS*)buf;
    //根据不同结果显示
    switch(rs->result) { 
    case room_no_exist:
        QMessageBox::about(m_fiveInLineZone, "提示", "房间不存在，进入房间失败");
        break;
    case join_success_host:
        //TODO 以房主视角进入房间
        m_fiveInLineZone->hide();
        m_isHost = true;
        m_roomDialog->setInfo(rs->roomID);
        m_roomDialog->show();
        break;
    case join_fail_host:
        QMessageBox::about(m_fiveInLineZone, "提示", "非房主权限，进入房间失败");
        break;
    case join_success_player:
        //TODO 以客场视角进入房间
        m_fiveInLineZone->hide();
        m_isPlayer = true;
        m_roomDialog->setInfo(rs->roomID);
        m_roomDialog->show();
        break;
    case join_fail_player:
        QMessageBox::about(m_fiveInLineZone, "提示", "玩家席已满，请进入观战席");
        break;    
    case join_success_watcher:
        //TODO 以观战视角进入房间
        m_fiveInLineZone->hide();
        m_isWatcher = true;
        m_roomDialog->setInfo(rs->roomID);
        m_roomDialog->show();
        break;
    case join_fail_watcher:
        QMessageBox::about(m_fiveInLineZone, "提示", "房间已满，进入房间失败");
        break;
    default:
        QMessageBox::about(m_fiveInLineZone, "提示", "注册异常， 注册失败");
    }
}

void CKernel::slot_AddFriendRq(unsigned int lSendIP, char *buf, int nLen)
{

}

//void CKernel::slot_ChatInZone(QString chatBuf)
//{

//}



void CKernel::slot_AddFriendRs(unsigned int lSendIP, char *buf, int nLen)
{

}

void CKernel::slot_offLineRq(unsigned int lSendIP, char *buf, int nLen)
{
    qDebug()<<"CKernel::slot_offLineRq";
    InitToLogin();
    QMessageBox::about(m_logindialog, "提示", "该账号已异地登录，您的登录已过期，请注意账号安全！");

}

void CKernel::slot_quitToZone()
{
    
}

void CKernel::slot_StartGameRq(int userID)
{

}

void CKernel::slot_StartGameRs(unsigned int lSendIP, char *buf, int nLen)
{

}

//void CKernel::slot_AudioOpen()
//{
//     qDebug() << "CKernel::slot_AudioClose";
//    //创建一条线程，用来采集语音，然后将采集到的语音数据发送出去
//}

//void CKernel::slot_AudioClose()
//{
//    qDebug() << "CKernel::slot_AudioClose";
//    //向线程发送停止采集语音的自定义信号并结束线程

//}

//void CKernel::slot_VideoOpen()
//{
//    qDebug() << "CKernel::slot_VideoOpen";
//    //创建一条线程，用来采集摄像头，然后将采集到的画面数据呈现到roomdialog的wdg_own上
//}

//void CKernel::slot_VideoClose()
//{
//    //向线程发送停止采集摄像头的自定义信号并结束线程
//}


void CKernel::slot_dealVideoInfo(unsigned int lSendIP, char *buf, int nLen)
{
    qDebug() << "CKernel::slot_dealVideoInfo";
    //读取buf中的数据并将图片数据呈现到roomdialog的wdg_friend上
}






void CKernel::slot_accessFiveInLine()
{
    qDebug() <<" CKernel::slot_accessFiveInLine";
    //页面转换
    m_mainDialog->hide();
    m_fiveInLineZone->GetUserInfo(userID, userName, winCount, failCount);
    m_fiveInLineZone->show();

}
