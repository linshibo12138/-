﻿#ifndef CKERNEL_H
#define CKERNEL_H

#include "packdef.h"
#include "maindialog.h"
#include "TcpClientMediator.h"
#include "logindialog.h"
#include "fiveinlinezone.h"
#include "roomdialog.h"
#include "roomitem.h"

//成员函数指针类型
class CKernel;
typedef void (CKernel::*PFUN)(unsigned int , char*, int);


//单例--最简单
class CKernel : public QObject
{
    Q_OBJECT
public:
    static CKernel* GetInstance() {
        static CKernel kernel;
        return &kernel;
    }

    void setNetPackFunMap();
    void SendData(char* buf, int nLen);


    void InitToLogin();
    void LeaveLogin();
private:
    explicit CKernel(QObject *parent = 0);
    ~CKernel();
    CKernel(const CKernel& kernel){}
    CKernel operator= (const CKernel& kernel){
        return *this;
    }

private:
    //成员属性
    //ui类对象
    MainDialog* m_mainDialog;    
    LoginDialog* m_logindialog;
    FiveInLineZone* m_fiveInLineZone;
    RoomDialog* m_roomDialog;

    //网络
    INetMediator* m_client;
    //协议映射表
    vector<PFUN> m_netPackFunMap;
    //文件上传任务映射
    //文件下载任务映射
    //好友ID与对话窗口对象指针映射
    //好友ID列表
    //排行榜list

    //个人信息
    int userID;
    int roomID;
    int zoneID;
    int winCount;
    int failCount;
    QString userName;
    char m_server_IP[20];
    bool m_isHost;
    bool m_isPlayer;
    bool m_isWatcher;
    int watcherCount;
    

public slots:
    //登录注册页面
    void slot_dealLoginRs(unsigned int lSendIP, char* buf, int nLen);
    void slot_dealRegisterRs(unsigned int lSendIP, char* buf, int nLen);
    void slot_loginCommit(QString tel, QString passwd);
    void slot_RegisterCommit(QString tel, QString name, QString passwd);
    //平台内
    void slot_JoinZoneRq(int zoneID);
    void slot_accessFiveInLine();
    void slot_offLineRq(unsigned int lSendIP, char* buf, int nLen);
    //专区内
    void slot_joinRoomRq(int roomID, int status);
    void slot_joinRoomRs(unsigned int lSendIP, char* buf, int nLen);
    void slot_AddFriendRq(unsigned int lSendIP, char* buf, int nLen);
    void slot_AddFriendRs(unsigned int lSendIP, char* buf, int nLen);
    void slot_quitToMainDialog();
    //房间内
    void slot_quitToZone();
    void slot_StartGameRq(int userID);
    void slot_StartGameRs(unsigned int lSendIP, char* buf, int nLen);
    void slot_dealVideoInfo(unsigned int lSendIP, char* buf, int nLen);
    //中心控制
    void DestroyInstance();    
    void slot_ReadyData(unsigned int lSendIP , char* buf , int nlen);











};

#endif // CKERNEL_H
