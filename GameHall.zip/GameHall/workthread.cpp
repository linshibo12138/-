﻿#include "workthread.h"



WorkThread::WorkThread(QObject *parent)
{
    m_thread = new QThread;
    //将该对象放入新建线程，以后执行的信号对应的槽函数都执行在这个线程里
    this->moveToThread(m_thread);


}

WorkThread::~WorkThread()
{
    if(m_thread) {
        m_thread->quit();
        m_thread->wait(100);
        if(m_thread->isRunning()) {
            m_thread->terminate();
        }
        delete m_thread;
        m_thread = nullptr;
    }
}


void FileThread::slot_StartRun()
{
    //开启线程
    m_thread->start();
}

void FileThread::slot_FileUpLoadWork(QString FilePath, QString FileName)
{

}

void FileThread::slot_FileUpLoadTaskWork(unsigned int lSendIP, char *buf, int nLen)
{

}

void FileThread::slot_FileDownLoadWork(QString FileKey)
{

}

void FileThread::slot_FileDownLoadTaskWork(unsigned int lSendIP, char *buf, int nLen)
{

}

void RoomThread::slot_AudioOpen()
{

}

void RoomThread::slot_AudioClose()
{

}

void RoomThread::slot_VideoOpen()
{

}

void RoomThread::slot_VideoClose()
{

}

void RoomThread::slot_dealVideoInfo()
{

}

void RoomThread::slot_ChatInRoom(int roomID)
{

}

void ZoneThread::slot_StartRun()
{

}

void ZoneThread::slot_quickplay(int userID)
{

}

void ZoneThread::slot_ChatInZone(int zoneID)
{

}

void ZoneThread::slot_AddNewFriend(int zoneID, int friendID)
{

}

void ZoneThread::slot_ChatWithFriend(int friendID, QString chatBuf)
{

}
