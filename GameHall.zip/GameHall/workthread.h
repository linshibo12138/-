﻿#ifndef WORKTHREAD_H
#define WORKTHREAD_H
#include <QObject>
#include <QThread>
#include <QDebug>


class WorkThread : public QObject
{
    Q_OBJECT
public:
    explicit WorkThread(QObject* parent = nullptr);
    ~WorkThread();
signals:

protected:
    QThread* m_thread;
};

class FileThread : public WorkThread {
    Q_OBJECT

signals:

public:

public slots:
    void slot_StartRun();
    void slot_FileUpLoadWork(QString FilePath, QString FileName);
    void slot_FileUpLoadTaskWork(unsigned int lSendIP, char* buf, int nLen);
    void slot_FileDownLoadWork(QString FileKey);
    void slot_FileDownLoadTaskWork(unsigned int lSendIP, char* buf, int nLen);
};

class ZoneThread : public WorkThread {
    Q_OBJECT

signals:

public:

public slots:
    void slot_StartRun();
    void slot_quickplay(int userID);
    void slot_ChatInZone(int zoneID);
    void slot_AddNewFriend(int zoneID, int friendID);
    void slot_ChatWithFriend(int friendID, QString chatBuf);
};

class RoomThread : public WorkThread {
    Q_OBJECT

signals:

public:

public slots:
    void slot_AudioOpen();
    void slot_AudioClose();
    void slot_VideoOpen();
    void slot_VideoClose();
    void slot_dealVideoInfo(/*视频数据包*/);
    void slot_ChatInRoom(int roomID);
};

#endif // WORKTHREAD_H
