﻿#ifndef ROOMDIALOG_H
#define ROOMDIALOG_H

#include "packdef.h"
#include<QHBoxLayout>
#include "fiveinline.h"

namespace Ui {
class RoomDialog;
}

class RoomDialog : public QDialog
{
    Q_OBJECT

public:
    explicit RoomDialog(QWidget *parent = 0);
    ~RoomDialog();
    void setInfo(int roomID);
    void joinerInHost();
    void closeEvent(QCloseEvent *e);
signals:
    void SIG_RoomClose();
    void SIG_AudioOpen();
    void SIG_AudioClose();
    void SIG_VideoOpen();
    void SIG_VideoClose();
private slots:

    void on_cb_audio_clicked();

    void on_cb_video_clicked();

private:
    Ui::RoomDialog *ui;
    QHBoxLayout * m_playLayout;
    int roomId;
    FiveInLine * m_fiveInline;
};

#endif // ROOMDIALOG_H
