﻿#ifndef AUDIO_WRITE_H
#define AUDIO_WRITE_H

#include "audio_common.h"
#include <QObject>

class audio_write : public QObject {
    Q_OBJECT
public:
    explicit audio_write(QObject* parent = nullptr);
    ~audio_write();
    //为了更好的管理状态, 需要添加状态位, 避免出现 (开始->开始 暂停->暂停 状态的切换)
    //初始化状态为结束 , 开始状态为 recording , 暂停状态为 pausing , 先判断再执行开始和暂停
    enum audio_state{Stop, Record, Pause};
signals:
     //定时采集的数据，以信号形式发送
    void SIG_audioFrame(QByteArray ba);
public slots:

    void slot_net_rx(QByteArray ba);
private:
    QAudioFormat  format;
    QTimer*       m_timer;
    QIODevice*    myBuffer_out;
    QAudioOutput*  audio_out;
    int           m_recordState;
};

#endif // AUDIO_WRITE_H
