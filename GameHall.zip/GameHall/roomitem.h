﻿#ifndef ROOMITEM_H
#define ROOMITEM_H

#include "packdef.h"

namespace Ui {
class RoomItem;
}

class RoomItem : public QDialog
{
    Q_OBJECT

public:
    /*explicit */RoomItem(int roomID, QWidget *parent = 0);
    ~RoomItem();
    void setInfo();
signals:
    void SIG_JoinRoomInFreedom(int, int);
    void SIG_Close();
private slots:

    void on_pb_GoToWatch_clicked();

    void on_pb_GoToPlay_clicked();

private:
    int RoomID;
    Ui::RoomItem *ui;
    ROOM_INFO* info;
};

#endif // ROOMITEM_H
