﻿#include "maindialog.h"
#include "ui_maindialog.h"

MainDialog::MainDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MainDialog)
{
    qDebug() << __func__;
    ui->setupUi(this);
}

MainDialog::~MainDialog()
{
    qDebug() << __func__;
    delete ui;
}

void MainDialog::registerEvent(string userName)
{
    qDebug() << "MainDialog::registerEvent";
    ui->pb_icon->setIcon(QIcon(QPixmap(_DEF_DEFAULT_ICON)));
    ui->pb_icon->setIconSize(QSize(_DEF_HALL_ICON_WIDTH, _DEF_HALL_ICON_HEIGHT));
    ui->le_userName->setText(QString::fromStdString(userName));
}

void MainDialog::closeEvent(QCloseEvent *e)
{
    qDebug() << "MainDialog::closeEvent";
    if(QMessageBox::question(this, "退出", "是否退出") == QMessageBox::Yes) {
        //发信号
        Q_EMIT SIG_close();
        //同意关闭事件
        e->accept();
    }
    else {
        //忽略关闭事件
        e->ignore();
    }

}



void MainDialog::on_pb_FiveInLine_clicked()
{
    qDebug() << "MainDialog::on_pb_FiveInLine_clicked";
    //页面显示
    Q_EMIT SIG_joinZone(ENUM_FiveInLine);
}



void MainDialog::on_pb_FileUpload_clicked()
{
    qDebug() << "MainDialog::on_pb_FileUpload_clicked";
}

void MainDialog::on_pb_FileUpLoad_clicked()
{
    qDebug() << "MainDialog::on_pb_FileUpLoad_clicked";
    //打开本地目录
    //读取目标文件信息
    //向kernel发送信号，创建一个线程去上传文件
}


void MainDialog::on_pb_FileDownLoad_clicked()
{
    qDebug() << "MainDialog::on_pb_FileDownLoad_clicked";
    //读取lineEdit中的字符串
    //向kernel发送信号，创建一个线程
}

