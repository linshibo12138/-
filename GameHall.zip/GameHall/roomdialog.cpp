﻿#include "roomdialog.h"
#include "ui_roomdialog.h"

RoomDialog::RoomDialog(QWidget *parent) : QDialog(parent), ui(new Ui::RoomDialog)
{
    ui->setupUi(this);

    m_playLayout = new QHBoxLayout;
    m_playLayout->setContentsMargins( 0,0,0,0);
    ui->wdg_broad->setLayout(  m_playLayout );

    m_fiveInline = new FiveInLine;
    m_playLayout->addWidget( m_fiveInline );

}

RoomDialog::~RoomDialog()
{
    delete ui;
}

void RoomDialog::setInfo(int roomID)
{
    qDebug() << "RoomDialog::setInfo";
    QString txt = QString("五子棋-%1房").arg(roomID, 2, 10, QChar('0'));
    this->setWindowTitle(txt);
}

void RoomDialog::joinerInHost()
{


}

void RoomDialog::closeEvent(QCloseEvent *e)
{
    qDebug() << "RoomDialog::closeEvent";
    if(QMessageBox::question(this, "退出", "是否退出") == QMessageBox::Yes) {
        //发信号
        Q_EMIT SIG_RoomClose();
        //同意关闭事件
        e->accept();
    }
    else {
        //忽略关闭事件
        e->ignore();
    }
}





void RoomDialog::on_cb_audio_clicked()
{
    if(ui->cb_audio->isChecked() == false) {//开启语音
        ui->cb_audio->setChecked(true);
        //向kernel发送信号，将麦克风打开，并开启一条线程负责将采集到的声音打包发送出去

    }
    else {//关闭语音
        ui->cb_audio->setChecked(false);
        //向kernel发送信号，将麦克风关闭，并将新开启的线程关闭
    }
}


void RoomDialog::on_cb_video_clicked()
{
    if(ui->cb_video->isChecked() == false) {//开启视频
        ui->cb_video->setChecked(true);
        //向kernel发送信号，将摄像头打开，并开启一条线程负责将采集到的画面呈现在wdg_own上

    }
    else {//关闭视频
        ui->cb_video->setChecked(false);
        //向kernel发送信号，将摄像头关闭，并将新开启的线程关闭
    }
}

