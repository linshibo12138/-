﻿#include "audio_read.h"


audio_read::audio_read(QObject *parent)
{
    //初始化设备
    //声卡采样格式
    format.setSampleRate(8000);
    format.setChannelCount(1);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::UnSignedInt);
    QAudioDeviceInfo info = QAudioDeviceInfo::defaultInputDevice();
    if (!info.isFormatSupported(format)) {
        QMessageBox::information(NULL , "提示", "打开音频设备失败");
        format = info.nearestFormat(format);
    }
    m_recordState = audio_state::Stop;
}

audio_read::~audio_read()
{
    if(audio_in) {
        audio_in->stop();
        delete audio_in;
    }
    //m_timer->stop();
    //delete m_timer;
}

//开启采集
void audio_read::start()
{
    if(m_recordState != audio_state::Record) {
        audio_in = new QAudioInput(format, this);
        myBuffer_in = audio_in->start();//声音采集开始
        //通过定时器, 每次超时, 从缓冲区 m_buffer_in 中提取数据
 //       QTimer * timer = new QTimer(this); //(父类负责回收子控件);
//        connect(timer , &QTimer::timeout , this , &Audio_Read::readMore);
 //       timer->start(20);
    }
    m_recordState = audio_state::Record;
}

//声音采集暂停
void audio_read::pause()
{
    if(m_recordState == audio_state::Record) {
        //声音采集恢复, 可以将原 QAudioInput 对象回收, 重新再申请
        if(audio_in)
        {
            audio_in->stop();
            delete audio_in;
        }
        //timer->stop();
     //   delete m_timer;
    }
    m_recordState = audio_state::Pause;
}
//定时器响应函数—将采集好的数据以信号的形式抛出
void audio_read::slot_readMore()
{
    if (!audio_in) return;
    QByteArray m_buffer(2048,0);
    qint64 len = audio_in->bytesReady();
    if (len < 640)
    {
        return;
    }
    //从音频设备对应的缓冲区中读取640字节
    qint64 l = myBuffer_in->read(m_buffer.data(), 640);
    QByteArray frame;
    frame.append(m_buffer.data(),640);
    Q_EMIT SIG_audioFrame( frame );
}
