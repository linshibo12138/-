#ifndef QUICKPLAY_H
#define QUICKPLAY_H


class QuickPlay
{
public:
    QuickPlay();
};

#endif // QUICKPLAY_H
