﻿#ifndef FIVEINLINEZONE_H
#define FIVEINLINEZONE_H

#include "packdef.h"
#include "roomitem.h"
#include "roomdialog.h"

namespace Ui {
class FiveInLineZone;
}

class FiveInLineZone : public QDialog
{
    Q_OBJECT

public:
    explicit FiveInLineZone(QWidget *parent = 0);
    ~FiveInLineZone();
    void GetUserInfo(int userID, QString userName, int winCount, int failCount);
    void closeEvent(QCloseEvent *e);
    //DestroyRoom();
    void HostJoinRoom(int userID);    
    void DestroyRoom();
signals:
    void SIG_close();
    void SIG_JOINROOM_RQ(int, int, int);
    void SIG_QUICKPLAY(int);
    
private slots:
    void on_pb_StartPlay_clicked();

    void on_pb_SendMessage_clicked();

    void slot_JoinRoomInFreedom(int roomID, int status);



private:
    int userID;
    Ui::FiveInLineZone *ui;
    QGridLayout* m_layout;
};

#endif // FIVEINLINEZONE_H
