#include "quickplay.h"

QuickPlay::QuickPlay()
{

}
